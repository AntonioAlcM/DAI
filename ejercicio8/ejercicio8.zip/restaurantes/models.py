from __future__ import unicode_literals

from django.db import models

from django.conf import settings

cliente_de_mongo = settings.CLIENT

