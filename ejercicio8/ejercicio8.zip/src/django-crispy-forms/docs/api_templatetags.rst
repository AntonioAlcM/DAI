==========================================
API templatetags
==========================================

.. automodule:: templatetags.crispy_forms_tags
  :members:
  :undoc-members:

.. automodule:: templatetags.crispy_forms_filters
  :members:
  :undoc-members:

.. automodule:: templatetags.crispy_forms_field
  :members:
  :undoc-members:
